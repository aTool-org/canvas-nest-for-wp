# canvas-nest-for-wp
A wordpress plugin of [canvas-nest.js](https://github.com/aTool-org/canvas-nest.js).

## How to use?

1. Download package from [release](https://github.com/aTool-org/canvas-nest-for-wp/releases)

2. unzip the package, and put the folder into `wp-content\plugins` dir.

3. refresh the admin page, click `OPEN` the plugin.


## Node

 - Code template from [fyaconiello/wp_plugin_template](https://github.com/fyaconiello/wp_plugin_template)